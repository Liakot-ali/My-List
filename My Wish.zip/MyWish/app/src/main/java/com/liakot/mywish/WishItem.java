package com.liakot.mywish;

import java.sql.Time;
import java.util.Date;

public class WishItem {

    private String wishTittle;
    private String wishHint;
    private Date date;


    public WishItem()
    {

    }

    public WishItem(String wishTittle, String wishHint, Date date) {
        this.wishTittle = wishTittle;
        this.wishHint = wishHint;
        this.date = date;
    }

    public String getWishTittle() {
        return wishTittle;
    }

    public void setWishTittle(String wishTittle) {
        this.wishTittle = wishTittle;
    }

    public String getWishHint() {
        return wishHint;
    }

    public void setWishHint(String wishHint) {
        this.wishHint = wishHint;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
