package com.liakot.mywish;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;

public class ActivityAddWish extends AppCompatActivity {
    Toolbar toolbar;
    EditText wishTittleET, wishStringET;
    Button addWishBtn;
    ListView myWishList;
    ArrayList<WishItem> arrayList;
    BaseAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_wish);

        //---------for back button----------
        toolbar = findViewById(R.id.toolbarDemo);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        wishTittleET = findViewById(R.id.wishTittleET);
        wishStringET = findViewById(R.id.wishStringET);
        addWishBtn = findViewById(R.id.addWishButton);

//        myWishList = findViewById(R.id.myWishList);
//        arrayList = new ArrayList<WishItem>();
//        adapter = new BaseAdapter() {
//            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//
//            @Override
//            public int getCount() {
//                return arrayList.size();
//            }
//
//            @Override
//            public Object getItem(int position) {
//                return arrayList.get(position);
//            }
//
//            @Override
//            public long getItemId(int position) {
//                return 0;
//            }
//
//            @SuppressLint("InflateParams")
//            @Override
//            public View getView(int position, View view, ViewGroup viewGroup) {
//                if (view == null) {
//                    view = inflater.inflate(R.layout.wish_item, null);
//                }
//                TextView wishTittleTV, wishTimeTV, wishHintTV, wishDateTV;
//                wishTittleTV = view.findViewById(R.id.wishTittleTV);
//                wishDateTV = view.findViewById(R.id.wishDateTV);
//                wishHintTV = view.findViewById(R.id.wishHintTV);
//                wishTimeTV = view.findViewById(R.id.wishTimeTV);
//
//                wishTittleTV.setText(arrayList.get(position).getWishTittle());
//                wishHintTV.setText(arrayList.get(position).getWishHint());
//
//                Date date = arrayList.get(position).getDate();
//                wishTimeTV.setText(DateFormat.format("HH:mm:ss a", date));
//                wishDateTV.setText(DateFormat.format("dd/MM/yyyy", date));
//
//                return view;
//            }
//        };
//        myWishList.setAdapter(adapter);

        addWishBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String wishTittleSt, wishSt, dateSt, timeSt;
                Date date = new Date();
                wishTittleSt = wishTittleET.getText().toString();
                wishSt = wishStringET.getText().toString();

                Bundle bundle = new Bundle();
                bundle.putString("wish tittle", "wishTittleSt");
                ;
                bundle.putString("wish hint", "wishSt");
                FragmentMyWish wish = new FragmentMyWish();
                wish.setArguments(bundle);


//                WishItem item = new WishItem(wishTittleSt, wishSt, date);
//                arrayList.add(item);
//
//                adapter.notifyDataSetChanged();
//
//                wishStringET.setText("");
//                wishStringET.setText("");
//                InputMethodManager methodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
//                assert methodManager != null;
//                methodManager.hideSoftInputFromWindow(wishStringET.getWindowToken(),0);

                Toast.makeText(getApplicationContext(), "Wish Added", Toast.LENGTH_SHORT).show();

            }
        });


    }

    //---------for back to home-------------
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
