package com.liakot.mywish;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.Date;

import static androidx.core.content.ContextCompat.getSystemService;

public class FragmentMyWish extends Fragment {

    private ListView myWishListView;
    private ArrayList<WishItem> arrayList;
    private BaseAdapter adapter;
    private String wishTittle, wishString, wishTime, wishDate;
    private Date date;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_my_wish, container, false);

        assert getArguments() != null;
            wishTittle = this.getArguments().getString("wish tittle");
            wishString = this.getArguments().getString("wish hint");

        Button newWishBtn = view.findViewById(R.id.createNewWishBtn);
        Button refresh = view.findViewById(R.id.refresh);
        myWishListView = view.findViewById(R.id.myWishListView);

        arrayList = new ArrayList<WishItem>();

        adapter = new BaseAdapter() {
            LayoutInflater inflater = (LayoutInflater) getContext().getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//            LayoutInflater inflater =(LayoutInflater) getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            @Override
            public int getCount() {
                return arrayList.size();
            }

            @Override
            public Object getItem(int position) {
                return arrayList.get(position);
            }

            @Override
            public long getItemId(int position) {
                return 0;
            }

            @Override
            public View getView(int position, View view1, ViewGroup viewGroup) {
                if (view1 == null) {
                    view1 = inflater.inflate(R.layout.wish_item, null);
                }
                TextView wishTittleTV, wishTimeTV, wishHintTV, wishDateTV;
                wishTittleTV = view1.findViewById(R.id.wishTittleTV);
                wishDateTV = view1.findViewById(R.id.wishDateTV);
                wishHintTV = view1.findViewById(R.id.wishHintTV);
                wishTimeTV = view1.findViewById(R.id.wishTimeTV);

                wishTittleTV.setText(arrayList.get(position).getWishTittle());
                wishHintTV.setText(arrayList.get(position).getWishHint());

                Date date = arrayList.get(position).getDate();
                wishTimeTV.setText(DateFormat.format("HH:mm:ss a", date));
                wishDateTV.setText(DateFormat.format("dd/MM/yyyy", date));

                return view1;
            }
        };

        myWishListView.setAdapter(adapter);

        WishItem item = new WishItem(wishTittle, wishString, new Date());
        arrayList.add(item);
        adapter.notifyDataSetChanged();

//        refresh.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
////                WishItem item = new WishItem(wishTittle, wishString, new Date());
////                arrayList.add(item);
////                adapter.notifyDataSetChanged();
//            }
//        });

        newWishBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ActivityAddWish.class);
                startActivity(intent);
            }
        });

        return view;
    }
}
